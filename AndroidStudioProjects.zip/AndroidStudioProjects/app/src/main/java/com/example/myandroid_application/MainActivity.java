package com.example.myandroid_application;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText eName;
    private EditText ePassword;
    private Button eLogin;
    private TextView eAttemptsInfo;
    private int counter = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eName = (EditText) findViewById(R.id.etName);
        ePassword = (EditText)findViewById(R.id.etPassword);
        eLogin = (Button) findViewById(R.id.btnLogin);
        eAttemptsInfo =(TextView) findViewById(R.id.tvAttemptsInfo);
        //eAttemptsInfo.setText("No of attempts remaining : 5  " );

        eLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(eName.getText().toString(), ePassword.getText().toString());
            }
        });
    }
    private void validate( String userName, String password){
        if(userName.equals("Moinuddin") && (password.equals("12345"))){
            Intent intent = new Intent(MainActivity.this, HomePageActivity.class);
            startActivity(intent);
        }else{
            counter--;
            //eAttemptsInfo.setText("No of attempts remaining : " +String.valueOf(counter));
            eAttemptsInfo.setText("Incorrect Password");

        }
    }


}