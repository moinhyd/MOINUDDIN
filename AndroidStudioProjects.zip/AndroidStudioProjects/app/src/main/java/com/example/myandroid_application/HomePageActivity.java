package com.example.myandroid_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomePageActivity extends AppCompatActivity {

    //Step 1
    private Button btnbaby;
    private Button btnmed;
    private Button btnvit;
    private Button btnequ, btnExit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        //Step 2
        btnbaby = (Button)findViewById(R.id.btnbaby);
        btnmed = (Button) findViewById(R.id.btnmed);
        btnvit = (Button) findViewById(R.id.btnvit);
        btnequ = (Button) findViewById(R.id.btnequ);
        btnExit = (Button)findViewById(R.id.btnExit);

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveTaskToBack(true);
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(1);
            }
        });

        btnvit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePageActivity.this, VitaminActivity.class);
                startActivity(intent);
            }
        });

      btnequ.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Intent intent = new Intent(HomePageActivity.this, diagnosticActivity.class);
              startActivity(intent);
          }
      });
        btnmed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePageActivity.this , medicinesActivity.class);
                startActivity(intent);
            }
        });
        btnbaby.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePageActivity.this, babyActivity.class);
                startActivity(intent);
            }
        });

    }
}